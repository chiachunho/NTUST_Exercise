// Student ID: B10615043
// Date: June 11, 2018
// Last Update: June 11, 2018
// Problem statement: This C++ header to declare class InsufficientFunds.
#pragma once

class InsufficientFunds
{
};