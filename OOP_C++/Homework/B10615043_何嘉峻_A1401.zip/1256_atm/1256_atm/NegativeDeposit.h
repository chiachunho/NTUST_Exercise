// Student ID: B10615043
// Date: June 11, 2018
// Last Update: June 11, 2018
// Problem statement: This C++ header to declare class NegativeDeposit.
#pragma once

class NegativeDeposit
{
};