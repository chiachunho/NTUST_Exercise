////Name: PWC
////Date: March 19, 2016
////Last Update: March 27, 2017
////Problem statement: ��ƥ[��
//
//#include <iostream>
//#include "PrimeNumber.h"
//using namespace std;
//
//int main()
//{
//	//Create two object form different constructor
//	PrimeNumber p1, p2(13);
//	//get p1's number
//	cout << "p1 = " << p1.get() << endl;
//	//get p2's number
//	cout << "p2 = " << p2.get() << endl;
//	cout << endl;
//
//	//doing postfix ++ operator
//	PrimeNumber p3 = p1++;
//	//get p1's number
//	cout << "p1 = " << p1.get() << endl;
//	//get p3's number
//	cout << "p3 = " << p3.get() << endl;
//	cout << endl;
//
//	//doing prefix ++ operator
//	p3 = ++p1;
//	//get p1's number
//	cout << "p1 = " << p1.get() << endl;
//	//get p3's number
//	cout << "p3 = " << p3.get() << endl;
//	cout << endl;
//
//	//doing postfix -- operator
//	PrimeNumber p5 = p2--;
//	//get p2's number
//	cout << "p2 = " << p2.get() << endl;
//	//get p5's number
//	cout << "p5 = " << p5.get() << endl;
//	cout << endl;
//
//	//doing prefix -- operator
//	p5 = --p2;
//	//get p2's number
//	cout << "p2 = " << p2.get() << endl;
//	//get p5's number
//	cout << "p5 = " << p5.get() << endl;
//	cout << endl;
//
//	system("pause");
//	return 0;
//}
