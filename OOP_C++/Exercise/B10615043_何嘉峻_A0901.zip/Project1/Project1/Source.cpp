// Student ID: B10615043
// Date: April 26, 2018
// Last Update: April 26, 2018
// Problem statement: This C++ program to check friendship.
#include <iostream>

using namespace std;
int shipList[20000];	// friendship list
int boss(int);			// to find boss of friendship

int main()
{
	int N, M, Q;

	while (cin >> N >> M >> Q)
	{
		for (int i = 0; i <= N; i++)
		{
			shipList[i] = i;	//initial array value
		}
		for (int i = 0; i < M; i++)
		{
			int A, B;
			cin >> A >> B;
			A = boss(A);		// write boss
			B = boss(B);		// write boss
			shipList[B] = A;	// combine each boss
		}
		for (int i = 0; i < Q; i++)
		{
			int C, D;
			cin >> C >> D;
			if (boss(C) == boss(D)) // same boss
			{
				cout << ":)" << endl;
			}
			else
			{
				cout << ":(" << endl;
			}
		}
	}
	return 0;
}

// Intent: to find friend boss.
// Pre: index.
// Post: friend boss.
int boss(int index)
{
	if (index == shipList[index])	// if index value equal index
	{
		return index;				// boss value
	}
	return shipList[index] = boss(shipList[index]);
}


