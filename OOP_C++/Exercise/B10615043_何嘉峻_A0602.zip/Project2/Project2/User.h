// Student ID: B10615043
// Date: I don't know(?
// Last Update: April 5, 2018
// Problem statement: This C++ program to declare class User.

#pragma once
#include <iostream>
#include <string>
#include "Connection.h"

class User {
public:
	// �����ثe���h��User
	static int userCount;
	// User���W��
	std::string name;
	// User���s�u��T
	Connection connection;

	// constructors
	User(std::string name, unsigned int ipAddress, unsigned short port);
	User(std::string name, unsigned char ipField1, unsigned char ipField2, unsigned char ipField3, unsigned char ipField4, unsigned short port);
	User(std::string name, unsigned int ipAddress);
	User(std::string name, unsigned char ipField1, unsigned char ipField2, unsigned char ipField3, unsigned char ipField4);
	User(std::string name);

	// ��������i�H�����ϥ�<<��X��ostream
	friend std::ostream& operator<<(std::ostream& outputStream, const User& user);

	// copy constructor
	User(const User&);

	//deconstructor
	~User();
};