// Student ID: B10615043
// Date: I don't know(?
// Last Update: April 5, 2018
// Problem statement: This C++ program to implementation class user.

#include "User.h"

int User::userCount = 0; // initialization value of user

// constructors
User::User(std::string name, unsigned int ipAddress, unsigned short port) :name(name), connection(ipAddress, port)
{
	userCount++;
}

User::User(std::string name, unsigned char ipField1, unsigned char ipField2, unsigned char ipField3, unsigned char ipField4, unsigned short port) : name(name), connection(ipField1, ipField2, ipField3, ipField4, port)
{
	userCount++;
}

User::User(std::string name, unsigned int ipAddress) : name(name), connection(ipAddress, 0)
{
	userCount++;
}

User::User(std::string name, unsigned char ipField1, unsigned char ipField2, unsigned char ipField3, unsigned char ipField4) : name(name), connection(ipField1, ipField2, ipField3, ipField4, 0)
{
	userCount++;
}

User::User(std::string name) : name(name), connection(0, 0)
{
	userCount++;
}

// ��������i�H�����ϥ�<<��X��ostream
std::ostream& operator<<(std::ostream& outputStream, const User& user) 
{
	std::cout << "User: " << user.name << ", ";
	std::cout << user.connection;
	return outputStream;
}

// copy constructor 
User::User(const User& copy) :name(copy.name), connection(copy.connection)
{
	userCount++; // to avoid vector reallocate affect static count variable
}

// deconstructor
User::~User()
{
	userCount--;
}