// Student ID: B10615043
// Date: March 15, 2018
// Last Update: March 15, 2018
// Problem statement: This C++ program computes sort and print factorial number.

#include <iostream>
#include <vector>
#include <algorithm> // include this to use "sort" function
#include <string>

using namespace std;

// Intent: to print the factorial number
// Pre: number n (n!)
// Post: print n! (factorial number)
string Factorial(int i)
{
	string fac[16] =
	{
		"1",					// 0!
		"1",					// 1!
		"2",					// 2!
		"6",					// 3!
		"24",					// 4!
		"120",					// 5!
		"720",					// 6!
		"5040",					// 7!
		"40320",				// 8!
		"362880",				// 9!
		"3628800",				// 10!
		"39916800",				// 11!
		"479001600",			// 12!
		"6227020800",			// 13!
		"87178291200",			// 14!
		"1307674368000"			// 15!
	};
	return fac[i];
}

int main()
{
	int num;
	while (cin >> num)
	{
		vector <int> list;

		//store value
		for (int i = 0; i < num; i++) {
			int temp;
			cin >> temp;
			list.push_back(temp);
		}

		//sort the list
		sort(list.begin(), list.end());

		//print the factorial number
		for (int i = 0; i < list.size(); i++)
		{
			if (!i) //when the first print
			{
				cout << Factorial(list[i]);
			}
			else //other condition
			{
				cout << "<" << Factorial(list[i]);
			}
		}
		cout << endl;
	}
}