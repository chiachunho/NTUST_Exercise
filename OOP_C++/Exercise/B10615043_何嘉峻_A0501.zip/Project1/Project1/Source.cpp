// Student ID: B10615043
// Date: March 29, 2018
// Last Update: March 29, 2018
// Problem statement: This C++ program to find where is point.
#include <iostream>
#include <vector>

using namespace std;

struct point
{
	double x;
	double y;
};

struct figure
{
	char type;	// r	c
	double a;	// x1	x
	double b;	// y1	y
	double c;	// x2	R
	double d;	// y2	(none)
};

int main()
{
	int n; // figure value
	while (cin >> n)
	{
		vector<figure> fgList; // figure list

		for (int i = 0; i < n; i++)
		{
			figure figureTemp;
			cin >> figureTemp.type;
			if (figureTemp.type == 'r')
			{
				cin >> figureTemp.a; // x1
				cin >> figureTemp.b; // y1
				cin >> figureTemp.c; // x2
				cin >> figureTemp.d; // y2
			}
			else if (figureTemp.type == 'c')
			{
				cin >> figureTemp.a; // x
				cin >> figureTemp.b; // y
				cin >> figureTemp.c; // R
			}
			fgList.push_back(figureTemp); // add to vector
		}

		vector<point> ptList; // point list

		int m; // point value
		cin >> m;
		for (int i = 0; i < m; i++)
		{
			point pt;
			cin >> pt.x >> pt.y;
			ptList.push_back(pt); // add to vector
		}
		for (int i=0;i<m;i++)
		{
			bool contain = false; // a flag to detect contained or not

			for (int j = 0; j < n; j++)
			{
				if (fgList[j].type == 'r')
				{
					if (ptList[i].x >= fgList[j].a && ptList[i].x <= fgList[j].c) // point in x range
					{
						if (ptList[i].y <= fgList[j].b && ptList[i].y >= fgList[j].d) // point in y range
						{
							cout << "Point (" << ptList[i].x << ", " << ptList[i].y << ") is contained in figure " << j+1 << endl;
							contain = true; // change flag
						}
					}
				}
				else if (fgList[j].type == 'c')
				{
					double distance = (ptList[i].x - fgList[j].a)*(ptList[i].x - fgList[j].a) + (ptList[i].y - fgList[j].b)*(ptList[i].y - fgList[j].b);
					if (distance <= fgList[j].c*fgList[j].c) // "distance <= radius" -> point in circle or on the circle
					{
						cout << "Point (" << ptList[i].x << ", " << ptList[i].y << ") is contained in figure " << j+1 << endl;
						contain = true; // change flag
					}
				}
			}
			if (!contain) // if point is not contained in any figure
			{
				cout << "Point (" << ptList[i].x << ", " << ptList[i].y << ") is not contained in any figure" << endl;
			}
		}
		fgList.clear(); // clear vector
		ptList.clear(); // clear vector
	}
	return 0;
}