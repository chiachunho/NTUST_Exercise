// Student ID: B10615043
// Date: March 8, 2018
// Last Update: March 8, 2018

#include <iostream>
#include <cmath>
#include <iomanip> 

using namespace std;

struct point 
{
	float x;
	float y;
};

int main()
{
	point a, b, c;

	while (cin >> a.x >> a.y) 
	{
		cin >> b.x >> b.y;
		cin >> c.x >> c.y;
		float area;
		area = 0.5 * abs((a.x - c.x) * (b.y - a.y) - (a.x - b.x) * (c.y - a.y));
		cout << fixed << setprecision(2) << area << endl;
	}
	return 0;
}