// Student ID: B10615043
// Date: April 19, 2018
// Last Update: April 19, 2018
// Problem statement: This C++ program to do Text repair.
#include <iostream>
#include <fstream>
#include <string>
#include <cctype> // toupper,tolower,isalpha

using namespace std;

int main()
{
	ifstream inputFile;					
	inputFile.open("Error.txt");		// open file
	string line;						// temp string to read file
	string context = "";				// string to save context

	// read file
	while (getline(inputFile, line))	
	{
		context += line;
		context += "\n";
	}
	inputFile.close();					// close file
	bool newSentence = true;			// to check new sentence or not
	for (int i = 0; i < context.size(); i++)
	{
		if (isalpha(context[i]))					// if is alpha
		{
			if (newSentence)						// if new sentence
			{
				context[i] = toupper(context[i]);	// toupper
				newSentence = false;				// change flag
			}
			else									// if in sentence
			{
				context[i] = tolower(context[i]);	// to
			}
		}
		else if (context[i] == '.')					// if detect dot
		{
			newSentence = true;						// change flag
		}
	}
	ofstream outputFile;			
	outputFile.open("Correct.txt");	// newfile
	outputFile << context;			// write in file
	outputFile.close();				// close file
	return 0;
}