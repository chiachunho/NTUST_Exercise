// Student ID: B10615043
// Date: March 29, 2018
// Last Update: March 29, 2018
// Problem statement: This C++ program to compute polynomial Multiplication.
#include <iostream>
#include <vector>

using namespace std;

struct polynomial
{
	int a; // 2
	int b; // 1
	int c; // 0
	int d; // pow
};

// Intent: to print result
// Pre: result vector
// Post: polynomial result
void print(vector <int> arr)
{
	bool flag = false; // a flag to record where polynomial begin 
	for (int i = 24; i >= 0; i--)
	{
		if (flag)
		{
			cout << " " << arr[i];
		}
		else if (arr[i]) // != 0
		{
			flag = true; //change flag
			cout << arr[i]; // start to cout
		}
		else if (!flag && !i) // if polynomial all 0
		{
			cout << arr[i]; //cout one "0"
		}
	}
	cout << endl;
}

int main()
{
	polynomial input;
	while (cin >> input.a)
	{
		cin >> input.b >> input.c >> input.d; // write in data
		vector <int> result = { input.c,input.b,input.a}; //add data to result
		result.resize(25); 
		if (input.d > 1)
		{
			while (input.d > 1)
			{
				input.d--;
				vector<int> process(25, 0); //new array
				for (int i = 0; i < 22; i++) //Multiplication process
				{
					process[i] += result[i] * input.c;
					process[i + 1] += result[i] * input.b;
					process[i + 2] += result[i] * input.a;
				}
				result = process;
				process.clear(); //clear vector
			}
			print(result); //call print function
		}
		else if (input.d == 1) // if d=1 ,don't need to do Multiplication process
		{
			print(result); //call print function
		}
		result.clear(); //clear vector
	}
	return 0;
}