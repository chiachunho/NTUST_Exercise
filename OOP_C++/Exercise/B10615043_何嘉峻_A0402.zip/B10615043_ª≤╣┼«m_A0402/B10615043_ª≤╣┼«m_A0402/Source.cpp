// Student ID: B10615043
// Date: March 22, 2018
// Last Update: March 22, 2018
// Problem statement: This C++ program compute PulseMaximize .

#include <iostream>
#include <string>
#include <vector>
#include <algorithm> //sort

using namespace std;

struct signal { //record propotion & batteries
	string generator;
	double propotion;
};

bool rule(signal i, signal j)  //rule to sort
{ 
	return (i.propotion > j.propotion);
}

int main()
{
	int num;
	while (cin >> num)
	{
		vector<signal> arr;
		for (int i = 0; i < num; i++)
		{
			signal tmp;
			cin >> tmp.generator;
			double len = tmp.generator.size();
			double one = 0;
			for (int i = 0; i < len; i++)
			{
				if (tmp.generator[i] == '1')
				{
					one++;
				}
			}
			tmp.propotion = one / len; //propotion
			arr.push_back(tmp); //add to array
		}

		sort(arr.begin(), arr.end(), rule); //sort by propotion

		string battery = ""; //blank string 
		for (int i = 0; i < num; i++)
		{
			battery += arr[i].generator; //strcat
		}
		int batteryLen = battery.size();
		int one = 0, zero = 0, pulse = 0;
		for (int i = 0; i < batteryLen; i++)
		{
			if (battery[i] == '0')
			{
				zero++;
				if (i == batteryLen - 1) //if last word is '0'
				{
					pulse += zero*one;
				}
			}
			else if (battery[i] == '1')
			{
				if (zero)
				{
					pulse += zero*one;
					zero = 0;
				}
				one++;
			}
		}
		cout << pulse << endl; //print max pulses
		arr.clear();
	}
	return 0;
}