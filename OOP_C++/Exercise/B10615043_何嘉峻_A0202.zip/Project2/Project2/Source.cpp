// Student ID: B10615043
// Date: March 8, 2018
// Last Update: March 8, 2018

#include <iostream>

using namespace std;

int main()
{
	int x1, y, x2;
	int left=0, right=0;
	int xLineValue[1024] = { 0 };

	while (cin >> x1 >> y >> x2)
	{
		if (left == 0 && right == 0)
		{
			left = x1;
			right = x2;
		}
		else
		{
			if (x1 < left) 
			{
				left = x1;
			}
			if (x2 > right)
			{
				right = x2;
			}
		}
		for (int i = x1; i < x2; i++)
		{
			if (y > xLineValue[i])
			{
				xLineValue[i] = y;
			}
		}
	}

	cout << left << " 0 ";
	cout << left << " " << xLineValue[left];
	int currentHeight = xLineValue[left];

	for (int i = left; i < right; i++)
	{
		if (xLineValue[i]!= currentHeight) 
		{
			cout << " " << i << " " << currentHeight;
			currentHeight = xLineValue[i];
			cout << " " << i << " " << currentHeight;
		}
	}

	cout << " " << right << " " << currentHeight;
	cout << " " << right << " 0" << endl;
	return 0;
}