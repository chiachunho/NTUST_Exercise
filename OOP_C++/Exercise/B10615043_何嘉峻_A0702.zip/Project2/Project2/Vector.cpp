// Student ID: B10615043
// Date: April 12, 2018
// Last Update: April 12, 2018
// Problem statement: This C++ header to declare implementation class Vector.
#include "Vector.h"

// constructor
Vector::Vector()
{
}

// constructor
Vector::Vector(float x, float y)
{
	this->x = x;
	this->y = y;
}

// Intent: do vector + vector.
// Pre: vector2.
// Post: return vector result.
const Vector Vector::operator+(const Vector & vector2)
{
	Vector tmp;
	tmp.x = x + vector2.x;
	tmp.y = y + vector2.y;
	return tmp;
}

// Intent: do vector - vector.
// Pre: vector2.
// Post: return vector result.
const Vector Vector::operator-(const Vector & vector2)
{
	Vector tmp;
	tmp.x = x - vector2.x;
	tmp.y = y - vector2.y;
	return tmp;
}

// Intent: do vector * vector.
// Pre: vector2.
// Post: return float result.
const float Vector::operator*(const Vector & vector2)
{
	return x*vector2.x + y*vector2.y;
	// a�Eb=a1b1+a2b2
}

// Intent: do vector * value.
// Pre: vector2.
// Post: return vector result.
const Vector Vector::operator*(const float & value)
{
	Vector tmp;
	tmp.x = x *value;
	tmp.y = y *value;
	return tmp;
}
