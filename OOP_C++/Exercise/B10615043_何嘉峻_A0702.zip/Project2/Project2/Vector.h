// Student ID: B10615043
// Date: April 12, 2018
// Last Update: April 12, 2018
// Problem statement: This C++ header to declare class Vector.
#pragma once
#include <iostream>

using namespace std;

class Vector
{
public:
	// variables
	float x, y;
	// constructor
	Vector();
	Vector(float, float);
	// operator overloading 
	const Vector operator +(const Vector& vector2);
	const Vector operator -(const Vector& vector2);
	const float operator *(const Vector& vector2);
	const Vector operator *(const float& value);
};
