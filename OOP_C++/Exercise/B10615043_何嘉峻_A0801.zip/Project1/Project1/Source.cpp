// Student ID: B10615043
// Date: April 19, 2018
// Last Update: April 19, 2018
// Problem statement: This C++ program to calculate division.
#include <iostream>

using namespace std;

int main()
{
	int a, b, n;
	while (cin >> a >> b >> n)
	{
		int intPart = a / b;	// integer part
		a = a%b;
		cout << intPart << ".";

		//to calculate decimal part
		while (n--)
		{
			a = a * 10;			
			int dec = a / b;
			cout << dec;
			a = a%b;
		}
		cout << endl;
	}
	return 0;
}