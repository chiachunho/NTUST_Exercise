// Student ID: B10615043
// Date: March 15, 2018
// Last Update: March 15, 2018
// Problem statement: This C++ program computes Differentiating polynomial.

#include <iostream>

using namespace std;

void Differential(int* coefficients);//no any printf or cout
void Differential(int* coefficients, int times); //no any printf or cout
void Print(int* coefficients);


int coe; //coefficient (N)

int main()
{
	int times; //(T)
	while (cin >> coe >> times)
	{
		int *coefficients = new int[coe]; //new array to store coefficient

		for (int i = coe - 1; i >= 0; i--)
		{
			cin >> coefficients[i];
		}

		Differential(coefficients, times);

		for (int i = 0; i < times; i++)
		{
			Differential(coefficients);
			Print(coefficients);
		}

		delete[] coefficients; //delete coefficient array
	}
}

// Intent: Differentiate polynomial in times and print differential result
// Pre: undiffetent polynomial and times
// Post: print differential result
void Differential(int* coefficients, int times)
{
	//Backup data
	int copyCoefficient = coe;
	int *copyCoefficients = new int[coe]; //new array to backup coefficient
	for (int i = coe - 1; i >= 0; i--)
	{
		copyCoefficients[i] = coefficients[i];
	}
	//Differential Process
	for (int i = 0; i < times; i++)
	{
		Differential(coefficients);
	}
	Print(coefficients);

	//Restore backup data
	coe = copyCoefficient;
	for (int i = coe - 1; i >= 0; i--)
	{
		coefficients[i] = copyCoefficients[i];
	}
	delete[] copyCoefficients; //delete backup coefficient array
}

// Intent: Differentiate polynomial once
// Pre: polynomial to be differentiate
// Post: return differential result
void Differential(int* coefficients)
{
	for (int i = 0; i <coe - 1; i++)
	{
		coefficients[i] = coefficients[i + 1] * (i + 1);
	}
	coe -= 1;
}

// Intent: Print polynomial
// Pre: polynomial to be print
// Post: print the polynomial
void Print(int* coefficients)
{
	for (int i = coe - 1; i >= 0; i--)
	{
		if (i != 0)
		{
			cout << coefficients[i] << " ";
		}
		else if (i == 0)
		{
			cout << coefficients[i] << endl;
		}
	}
}