// Student ID: B10615043
// Date: March 29, 2018
// Last Update: March 29, 2018
// Problem statement: This C++ program to help xiaoming register and print student's grade.
#include <iostream>
#include <string> // to use string
using namespace std;

#define MAX 10

class student
{
private:
	string name; //student name
	int number; //student number
	int total; //student total
public:
	void setDetails(); //function to write in data
	void getDetails(); //function to print data
};

// Intent: to write in data
// Pre: none
// Post: none
void student::setDetails()
{
	cin >> name >> number >> total;
}

// Intent: to print data
// Pre: none
// Post: student data and percentage
void student::getDetails()
{
	cout << "Student details:" << endl;
	cout << "Name:" << name << endl;
	cout << "Student Number:" << number << endl;
	cout << "Total:" << total << endl;
	if (total > 300) // if total >300 , need to print warning message
	{
		cout << "Total scores should be under 300!" << endl;
	}
	cout << "Percentage:" << ((float)total / (float)300) * 100 << endl;
}

int main()
{
	student std[MAX];       //array of objects creation
	int numberOfStudents;

	cout << "Enter total number of students: ";
	cin >> numberOfStudents;

	for (int i = 0; i< numberOfStudents; i++) {
		cout << "Enter details of student " << i + 1 << ":\n";
		std[i].setDetails();
	}

	cout << endl;

	for (int i = 0; i < numberOfStudents; i++) {
		cout << "Details of student " << (i + 1) << ":\n";
		std[i].getDetails();
		cout << endl;
	}

	system("pause");
	return 0;
}