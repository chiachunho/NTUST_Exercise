// Student ID: B10615043
// Date: April 19 , 2018
// Last Update: April 19, 2018
// Problem statement: This C++ program to search word in a file.
#include <iostream>
#include <fstream>
#include <string>
#include <vector>

using namespace std;

int main()
{
	ifstream inputFile;
	inputFile.open("Data.txt");			// open file
	string line;						// temp string to get sentence
	vector <string> data;				// a vector to save context
	while (getline(inputFile, line))
	{
		data.push_back(line);
	}
	string key;							// keyword
	while (cin >> key)
	{
		bool dataFound = false;						// a flag to check keyword in context or not
		for (int i = 0; i < data.size(); i++)
		{
			int position = data[i].find(key, 0);	// get keyword position
			if (position != string::npos)			// if no found keyword in sentence
			{
				dataFound = true;					// change flag
				cout << "The word " << key << " find at line " << i + 1 << ", position:";
				bool comma = false;
				while (position != string::npos)
				{
					if (comma)
					{
						cout << ", " << position + 1;
					}
					else
					{
						cout << position + 1;
						comma = true;
					}
					int newPosition = position + 1;
					position = data[i].find(key, newPosition); // find new position
				} 
				cout << endl;
			}
		}
		if (!dataFound)	
		{
			cout << "The word " << key << " not exist in this file." << endl;
		}
	}
	data.clear();
	inputFile.close();
	return 0;
}