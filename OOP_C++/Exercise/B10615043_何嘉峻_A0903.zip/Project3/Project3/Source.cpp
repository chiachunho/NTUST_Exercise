// Student ID: B10615043
// Date: April 26, 2018
// Last Update: April 26, 2018
// Problem statement: This C++ program to print board.
#include <iostream>
#include <string>

using namespace std;

int main()
{
	int W, H;
	cin >> W >> H;
	char **board;				// pointer of pointer
	board = new char*[H];
	for (int i = 0; i < H; i++) // initial board
	{
		board[i] = new char[W];
		for (int j = 0; j < W; j++)
		{
			board[i][j] = ' ';
		}
	}
	string command;
	while (cin >> command)
	{
		if (command == "RECT")
		{
			int ux, uy, dx, dy;
			char c;
			cin >> ux >> uy >> dx >> dy >> c;
			if (ux >= W)
			{
				ux = W - 1;
			}
			if (uy >= H)
			{
				uy = H - 1;
			}
			if (dx < 0)
			{
				dx = 0;
			}
			if (dy < 0)
			{
				dy = 0;
			}
			for (int i = dy; i <= uy; i++)
			{
				for (int j = dx; j <= ux; j++)
				{
					board[i][j] = c;
				}
			}
		}
		else if (command == "CIRCLE")
		{
			int cx, cy, r;
			char c;
			cin >> cx >> cy >> r >> c;
			int ux=cx+r, uy=cy+r, dx=cx-r, dy=cy-r;
			if (ux >= W)
			{
				ux = W - 1;
			}
			if (uy >= H)
			{
				uy = H - 1;
			}
			if (dx < 0)
			{
				dx = 0;
			}
			if (dy < 0)
			{
				dy = 0;
			}
			for (int i = dy; i <= uy; i++)
			{
				for (int j = dx; j <= ux; j++)
				{
					int distance = (j - cx)*(j - cx) + (i - cy)*(i - cy);
					if (distance <= r*r)
					{
						board[i][j] = c;
					}
				}
			}
		}
		else if (command == "DRAW")
		{
			for (int i = 0; i < H; i++)
			{
				for (int j = 0; j < W; j++)
				{
					cout << board[i][j];
				}
				cout << endl;
			}
		}
	}
	return 0;
}