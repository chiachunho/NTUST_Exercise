// Student ID: B10615043
// Date: April 26, 2018
// Last Update: April 26, 2018
// Problem statement: This C++ program to print hungry Caterpillar.
#include <iostream>
#include <vector>
#include <string>
#include <algorithm> // sort

using namespace std;

// Intent: rule to sort alpha.
// Pre: character.
// Post: boolen.
bool alphaSort(char a, char b)
{
	return a > b;
}

int main()
{
	vector <char> Caterpillar;
	string command;
	while (cin >> command)
	{
		if (command == "EAT")
		{
			string str;
			cin >> str;
			for (int i = 0; i < str.length(); i++)
			{
				Caterpillar.insert(Caterpillar.begin(),str[i]);
			}
		}
		else if (command == "PULL")
		{
			int len;
			cin >> len;
			for (int i = 0; i < len; i++)
			{
				Caterpillar.pop_back();
			}
		}
		else if (command == "THROW")
		{
			int len;
			cin >> len;
			for (int i = 0; i < len; i++)
			{
				Caterpillar.erase(Caterpillar.begin());
			}
		}
		else if (command == "CONSUME")
		{
			char ch;
			cin >> ch;

			for (int i = 0; i < Caterpillar.size(); i++)
			{
				if (Caterpillar[i] == ch)
				{
					Caterpillar.erase(Caterpillar.begin() + i);
				}
			}
		}
		else if (command == "SORT")
		{
			sort(Caterpillar.begin(), Caterpillar.end(),alphaSort);
		}

		//print Caterpillar result
		cout << "@";
		for (int i = 0; i < Caterpillar.size(); i++)
		{
			cout << "-" << Caterpillar[i];
		}
		cout << "-*" << endl;
		//@-y-r-e-g-n-u-H-o-S-m-A-I-*
	}
	Caterpillar.clear();
	return 0;
}