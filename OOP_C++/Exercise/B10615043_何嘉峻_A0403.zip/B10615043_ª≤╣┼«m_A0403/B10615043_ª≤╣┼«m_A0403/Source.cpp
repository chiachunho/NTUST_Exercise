// Student ID: B10615043
// Date: March 22, 2018
// Last Update: March 22, 2018
// Problem statement: This C++ program compute Unspoken RR Rules .

#include <iostream>
#include <string>
#include <vector>
#include "FakeRand.h"

using namespace std;

struct player {
	string name;
	int level;
	int queue;
	int estTime;
	int continueTime = 0;
	int totalTime = 0;
};

// Intent: To simulate if target player defeats his opponent.
// Pre: Pass target's level and opponent's level.
// Post: Return true if target wins, false if his opponent wins.
bool Win(const int &targetLv, const int &opponentLv) {
	double rate = pow(2, targetLv - opponentLv);
	return rand() / (RAND_MAX + 1.0) < rate / (rate + 1);
}

int main()
{
	int N;
	while (cin >> N)
	{
		vector<player> list;
		vector<int> queuing;

		player none
		{
			"none",
			0,
			0,
			0,
			0
		};
		list.push_back(none);

		for (int i = 0; i < N; i++)
		{
			player tmp;
			cin >> tmp.name;
			cin >> tmp.level;
			cin >> tmp.queue;
			cin >> tmp.estTime;
			list.push_back(tmp); //add to array list
		}
		int now = 0; //now time
		int machineA = 0, machineB = 0; //record player num
		int fightTime = 0;
		while (1)
		{
			now++; //add time
			int flag = 0; // detect any change in this time
			int exit = 0; // detect exit

			//queueing
			for (int i = 1; i <= N; i++)
			{
				if (list[i].queue == now)
				{
					flag++;
					if (machineA == 0) // A empty
					{
						machineA = i;
					}
					else if (machineB == 0) // B empty
					{
						machineB = i;
					}
					else
					{
						queuing.push_back(i); //add to eqeuing
					}
				}
				if (list[i].queue == 0) //already leave
				{
					exit++;
				}
			}
			if (exit == N-1) //no one else add to eqeuing
			{
				break;
			}

			//check fight condition
			if (machineA && machineB) // A&B exist
			{
				if (fightTime == 5) //round end
				{
					flag++;

					fightTime = 0; //reset
				
					//make result and detect stright win 5 times
					bool result;
					if (list[machineA].continueTime == 25) // if A win 5 times
					{
						result = false; //A must lose
						list[machineA].continueTime = 0;
					}
					else
					{
						result = Win(list[machineA].level - 1, list[machineB].level);
					}

					if (!result) //if B win >> A&B exchange seat 
					{
						int tmp;
						tmp = machineA;
						machineA = machineB;
						machineB = tmp;
					}
					// detect A want to leave or not
					if (list[machineA].estTime <= list[machineA].totalTime)
					{
						list[machineA] = none;
						machineA = 0;
						if (!queuing.empty())
						{
							machineA = queuing[0];
							queuing.erase(queuing.begin());
						}
					}
					// detect B want to leave or not
					if (list[machineB].estTime <= list[machineB].totalTime)
					{
						list[machineB] = none;
					}
					else
					{
						queuing.push_back(machineB);
					}
					machineB = 0;
					//if queuing exist
					if (!queuing.empty())
					{
						machineB = queuing[0];
						queuing.erase(queuing.begin());
					}
				}

				if (machineA && machineB) //if A&B exist
				{
					fightTime++;
					list[machineA].totalTime++;
					list[machineA].continueTime++;
					list[machineB].totalTime++;
					list[machineB].continueTime++;
				}

			}
			//print condition if any change in this 
			if (flag)
			{
				cout << now << ": " << list[machineA].name;
				if (machineA) //if wasn't none
				{
					cout << " lv" << list[machineA].level;
				}
				cout << " vs. " << list[machineB].name;
				if (machineB) //if wasn't none
				{
					cout << " lv" << list[machineB].level;
				}
				cout << " |";
				for (int i : queuing)
				{
					cout << " " << list[i].name;
				}
				cout << endl;
			}
		}
		queuing.clear();
		list.clear();
	}
	return 0;
}