// Student ID: B10615043
// Date: March 19, 2018
// Last Update: March 19, 2018
// Problem statement: This C++ program to find number A.

#include <iostream>
#include <sstream> //istringsteam
#include <vector>
#include <string>

using namespace std;

int main()
{
	string input;
	while (getline(cin, input))
	{
		vector <string> arr; // to save value
		vector <double> diff; // to save differ
		string token;
		int blank = 0; //record how many num 
		istringstream value(input);
		while (getline(value, token, ' ')) 
		{
			arr.push_back(token);
			blank++;
		}

		double A;
		cin >> A;

		cin.ignore(); //skip newline word

		value.str("");
		value.clear();//clear value(istringstream)

		value.str(input);

		while (1)
		{
			double tmp;
			value >> tmp;
			if (value.fail()) //end
			{
				break; 
			}
			diff.push_back(abs(tmp - A));
		}
		double min;
		for (int i = 0; i < blank; i++) //find min diff
		{
			if (!i)
			{
				min = diff[i];
			}
			else if (diff[i] < min)
			{
				min = diff[i];
			}
		}
		int plus = 0; //flag to detect first print
		for (int i = 0; i < blank; i++)
		{
			if (diff[i] == min)
			{
				if (!plus)
				{
					cout << arr[i];
					plus++;
				}
				else
				{
					cout << " + " << arr[i];
				}
			}
		}
		cout << endl;
		arr.clear();
		diff.clear();//clear vector
	}

	return 0;
}