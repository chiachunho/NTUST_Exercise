// Student ID: B10615043
// Date: April 12, 2018
// Last Update: April 12, 2018
// Problem statement: This C++ header to declare class Rect.
#pragma once
#include <iostream>
#include <sstream>

using namespace std;

class Rect
{
public:
	// constructor
	Rect();
	Rect(int, int, int, int);
	// operator overloading
	const Rect operator+ (const Rect& rect2);
	const Rect operator* (const Rect& rect2);
	// member function
	string toString();
private:
	// variable
	int x, y, width, height;
};

