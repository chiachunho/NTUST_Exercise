// Student ID: B10615043
// Date: April 12, 2018
// Last Update: April 12, 2018
// Problem statement: This C++ header to declare implementation class Rect.
#include "Rect.h"

// constructor
Rect::Rect()
{
	// all variable default 0
	this->x = 0;
	this->y = 0;
	this->width = 0;
	this->height = 0;
}

// constructor
Rect::Rect(int x, int y, int width, int height)
{
	this->x = x;
	this->y = y;
	this->width = width;
	this->height = height;
}

// Intent: to get min rect which include two rect.
// Pre: rect2.
// Post: return rect result.
const Rect Rect::operator+(const Rect & rect2)
{
	Rect left(x, y, width, height), right = rect2;
	Rect result;
	if (x > rect2.x)
	{
		Rect tmp = left;
		left = right;
		right = tmp;
	}

	result.x = left.x;

	if (right.x + right.width > left.x + left.width)
	{
		result.width = right.x + right.width - left.x;
	}
	else
	{
		result.width = left.width;
	}

	Rect up(x, y, width, height), down = rect2;
	if (y <rect2.y)
	{
		Rect tmp = up;
		up = down;
		down = tmp;
	}
	result.y = up.y;
	if (up.y - up.height > down.y - down.height)
	{
		result.height = up.y - (down.y - down.height);
	}
	else
	{
		result.height = up.height;
	}
	return result;
}

// Intent: to get overlapping rect.
// Pre: rect2.
// Post: return rect result.
const Rect Rect::operator*(const Rect & rect2)
{
	Rect left(x, y, width, height), right = rect2;

	Rect result;
	if (x > rect2.x)
	{
		Rect tmp = left;
		left = right;
		right = tmp;
	}

	if (left.x + width >= right.x)
	{
		if (right.y >= left.y - left.height && right.y <= left.y)
		{
			result.x = left.x + abs(right.x - left.x);
			result.y = left.y - abs(left.y - right.y);
			if (left.x + left.width < right.x + right.width)
			{
				result.width = (left.x + left.width) - right.x;
			}
			else
			{
				result.width = right.width;
			}
			if (left.y - left.height > right.y + right.height)
			{
				result.height = right.y - (left.y - left.height);
			}
			else
			{
				result.height = right.height;
			}
		}
		else if (right.y - right.height >= left.y - left.height && right.y - right.height <= left.y)
		{
			result.x = left.x + abs(right.x - left.x);
			result.y = left.y;
			if (left.x + left.width < right.x + right.width)
			{
				result.width = (left.x + left.width) - right.x;
			}
			else
			{
				result.width = right.width;
			}
			result.height = left.y - (right.y - right.height);
		}
		else if (right.y >= left.y && right.y - right.height <= left.y - left.height)
		{
			result.x = right.x;
			result.y = left.y;
			if (left.x + left.width < right.x + right.width)
			{
				result.width = (left.x + left.width) - right.x;
			}
			else
			{
				result.width = right.width;
			}
			result.height = left.height;
		}
		else if (right.y <= left.y && right.y - right.height >= left.y - left.height)
		{
			result.x = right.x;
			result.y = right.y;
			if (left.x + left.width < right.x + right.width)
			{
				result.width = (left.x + left.width) - right.x;
			}
			else
			{
				result.width = right.width;
			}
			result.height = right.height;
		}
	}
	else
	{
		cout << "Not overlapping" << endl;
	}
	return result;
}

// Intent: to get string rect to show.
// Pre: none.
// Post: return rect result string.
string Rect::toString()
{
	//( 0 , 1 , 11 , 10 )
	string result = "( " + to_string(x) + " , " + to_string(y) + " , " + to_string(width) + " , " + to_string(height) + " )";
	return result;
}
