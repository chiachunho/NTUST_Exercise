// Student ID: B10615043
// Date: March 15, 2018
// Last Update: March 15, 2018
// Problem statement: This C++ program computes number pyramid.

#include <iostream>
#include <string>
#include <vector>

using namespace std;

int main()
{
	string numString;
	while (cin >> numString)
	{
		int strLength = numString.size();

		vector <unsigned long long int> row;

		//A flag that record whether it is a valid number so far
		int nonZero = 0;

		for (int i = 0; i < strLength; i++)
		{
			if (!nonZero)
			{
				if (numString[i] != 48) //if wasn't 0
				{
					row.push_back(numString[i] - 48);
					nonZero++; //flag change
				}
				else if (i == strLength - 1)
				{
					row.push_back(numString[i] - 48);
				}
			}
			else
			{
				row.push_back(numString[i] - 48);
			}
		}

		int rowLength = row.size();
		while (rowLength > 1)
		{
			vector <unsigned long long int> temp;

			for (int i = 0; i < rowLength - 1; i++)
			{
				temp.push_back(row[i] + row[i + 1]);
			}

			row = temp; //recovered

			temp.clear();
			rowLength = row.size();
		}
		cout << (unsigned long long int)row[0] << endl; //print result

		row.clear();
	}
	return 0;
}