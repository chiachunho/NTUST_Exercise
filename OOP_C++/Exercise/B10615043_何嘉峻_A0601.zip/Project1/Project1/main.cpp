// Student ID: B10615043
// Date: I don't know(?
// Last Update: April 5, 2018
// Problem statement: This C++ program to help xiaoming who only can use cout to create a monster list.

#include <iostream> 
#include <vector>
#include "monster.h"

using namespace std;

// print menu
void menu();

// main funtion
int main() {
	int features;
	//�|��map���H���˥�map
	//���M��vector�]�Ook��
	vector<Monster> monster;
	
	// variable
	string name;
	float hp;
	float damage;
	float defense;
	float speed;

	menu();
	while (cin >> features)
	{
		if (features == 0)
		{
			cout << "Please enter monster state" << endl;

			
			cin >> name >> hp >> damage >> defense >> speed;		// enter the variables
			Monster newMonster(name, hp, damage, defense, speed);	// creater a new monster
			monster.push_back(newMonster);							// add to list

		}
		else if (features == 1)
		{
			cout << "Please enter monster name : ";

			cin >> name;					// enter the name
			for (Monster n : monster)		// list loop
			{
				if (n.GetName() == name)	// if find match monster
				{
					n.PrintAllState();		// call print state function
				}
			}

		}
		else if (features == 2)
		{
			cout << "Please enter monster name : ";

			cin >> name;								// enter the name
			for (int i = 0; i < monster.size(); i++)	// list loop
			{
				if (monster[i].GetName() == name)		// if find match monster
				{
					cout << "Please enter new state : ";				// print guide message
					cin >> name >> hp >> damage >> defense >> speed;	// enter the variables
					monster[i].SetName(name);							// call set Name	function
					monster[i].SetHP(hp);								// call set HP		function
					monster[i].SetDamage(damage);						// call set Damage	function
					monster[i].SetDefense(defense);						// call set Defense function
					monster[i].SetSpeed(speed);							// call set Speed	function
				}
			}

		}

		//���§ڧa������
		cout << endl;
		menu();
	}
	return 0;
}

// print menu
void menu()
{
	cout << "Create monster enter 0" << endl;
	cout << "Check state enter 1" << endl;
	cout << "Change state enter 2" << endl;
	cout << "Feature : ";
}