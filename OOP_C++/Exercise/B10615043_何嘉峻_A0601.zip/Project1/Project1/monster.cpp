// Student ID: B10615043
// Date: I don't know(?
// Last Update: April 5, 2018
// Problem statement: This C++ program to implementation class monster.

#include "monster.h"

Monster::Monster() // constructor
{
}

Monster::Monster(string name, float hp, float damage, float defense, float speed) // constructor
{
	SetName(name);
	SetHP(hp);
	SetDamage(damage);
	SetDefense(defense);
	SetSpeed(speed);
}

// Intent: Set robot name.
// Pre: name type of string.
// Post: none.
void Monster::SetName(string name)
{
	this->name = name;
}

// Intent: Set robot HP.
// Pre: HP type of float.
// Post: none.
void Monster::SetHP(float hp)
{
	this->hp = hp;
}

// Intent: Set robot damage.
// Pre: damage type of float.
// Post: none.
void Monster::SetDamage(float damage)
{
	this->damage = damage;
}

// Intent: Set robot defence.
// Pre: defence type of float.
// Post: none.
void Monster::SetDefense(float defence)
{
	this->defense = defence;
}

// Intent: Set robot speed.
// Pre: speed type of float.
// Post: none.
void Monster::SetSpeed(float speed)
{
	this->speed = speed;
}

// Intent: Print monster status.
// Pre: none.
// Post: cout all monster states.
void Monster::PrintAllState() 
{
	cout << "Name : " << GetName() << endl;
	cout << "Hp : " << GetHP() << endl;
	cout << "Damage : " << GetDamage() << endl;
	cout << "Defence : " << GetDefence() << endl;
	cout << "Speed : " << GetSpeed() << endl;
}

// Intent: Get Monster's Name.
// Pre: none.
// Post: return name of monster.
string Monster::GetName()
{
	return name;
}

// Intent: Get Monster's HP.
// Pre: none.
// Post: return HP of monster.
float Monster::GetHP()
{
	return hp;
}

// Intent: Get Monster's Damage.
// Pre: none.
// Post: return damage of monster.
float Monster::GetDamage()
{
	return damage;
}

// Intent: Get Monster's Defense.
// Pre: none.
// Post: return defense of monster.
float Monster::GetDefence()
{
	return defense;
}

// Intent: Get Monster's Speed.
// Pre: none.
// Post: return speed of monster.
float Monster::GetSpeed()
{
	return speed;
}


Monster::~Monster() //deconstructor
{
}