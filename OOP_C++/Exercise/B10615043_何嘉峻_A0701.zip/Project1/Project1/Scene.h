// Student ID: B10615043
// Date: April 12, 2018
// Last Update: April 12, 2018
// Problem statement: This C++ header to declare class Scene.
#pragma once
#include <iostream>
#include <string>
#include <vector>
#include <sstream>

using namespace std;

struct option
{
	string index;	// option index string
	string context;	// option context string
};

class Scene
{
public:
	// constructor
	Scene();
	Scene(string context);

	// operator << overloading
	friend ostream& operator <<(ostream& outputStream, const Scene& scene);
	
	// member functions
	bool opExist();
	string getOptionIndex(int);

private:
	string index;				// scene index
	string narration;			// scene narration
	vector <option> options;	// scene option list
};
