// Student ID: B10615043
// Date: April 12, 2018
// Last Update: April 12, 2018
// Problem statement: This C++ header to declare implementation class Scene.
#include "Scene.h"

// constructor
Scene::Scene()
{
}

// constructor
Scene::Scene(string context)
{
	istringstream iss(context); // to save all context
	string line;				// temp
	while (getline(iss, line))	// get one line context to temp
	{
		if (line[0] == '#')		// if read index
		{
			index = index.assign(line, 1, line.length());
		}
		else if (line[0] == '-') // if read option
		{
			option opTemp;
			int pointer = line.find("#", 0);
			opTemp.context = opTemp.context.assign(line, 1, pointer-2);			// assign option context
			opTemp.index = opTemp.index.assign(line, pointer+1, line.length()); // assign option index
			options.push_back(opTemp);											// add to option list
		}
		else					// if read narration
		{
			narration += line;
			narration += "\n";
		}
	}
}

// Intent: judge option list empty or not.
// Pre: none.
// Post: return true if list isn't empty.
bool Scene::opExist()
{
	if (Scene::options.size() == 0) // if option list is empty
	{
		return false;
	}
	else 
	{
		return true;
	}
}

// Intent: get option 's index.
// Pre: list integer list.
// Post: return option index string.
string Scene::getOptionIndex(int i)
{
	return Scene::options[i - 1].index;
}

// Intent: to output scene.
// Pre: class scene.
// Post: return outputstream.
ostream & operator<<(ostream & outputStream, const Scene & scene)
{
	outputStream << scene.narration;
	int size = scene.options.size();
	for (int i = 0; i < size; i++)
	{
		outputStream << "(" << i + 1 << ") " << scene.options[i].context << endl;
	}
	return outputStream;
}
