﻿#include <string>
#include <fstream>
#include <sstream>
#include <iostream>
#include <map>
#include "Scene.h"
using namespace std;

int main() 
{
	ifstream in("script.txt"); // data file
	string str(static_cast<stringstream const&>(stringstream() << in.rdbuf()).str()); // read file into string	

	istringstream iss(str);		// to save data string
	string context;				// one part context temp
	string line;				// one line context temp 
	map <string, Scene> Scenes; // to save all scenes

	while (getline(iss, line))	// read one line
	{
		if (line == "")			// if read one part end
		{
			int indexPointer = context.find("\n", 0);

			string index;		// scene index string
			index.assign(context, 1, indexPointer-1); 

			Scenes[index] = Scene(context); // add to map
			context = "";		// clear context string
		}
		else
		{
			context += line;	// add to context
			context += "\n";	// add newline
		}
	}

	string sceneIndex = "0";	// default loading #0 scene
	cout << Scenes[sceneIndex]; // print scene
	int input;
	while (cin >> input)
	{
		sceneIndex = Scenes[sceneIndex].getOptionIndex(input);  // get new scene index string
		cout << Scenes[sceneIndex];								// print scene
		if (Scenes[sceneIndex].opExist() == false)				// if is ending scene
		{
			break;												// break loop
		}
	}
	system("pause");
}