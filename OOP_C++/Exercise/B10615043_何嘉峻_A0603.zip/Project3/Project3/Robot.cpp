// Student ID: B10615043
// Date: I don't know(?
// Last Update: April 5, 2018
// Problem statement: This C++ program to implementation class robot.

#include "Robot.h"
#include <math.h> // sqrt

// constructors

Robot::Robot(double x, double y, double power)
{
	this->x = x;
	this->y = y;
	if (power > 0) 
	{
		this->power = power;
	}
	else // if power data illegal
	{
		this->power = 0;
	}
}

Robot::Robot(double x, double y)
{
	this->x = x;
	this->y = y;
	this->power = 100; // default 100 units
}

Robot::Robot(double x)
{
	this->x = x;
	this->y = 0;		// default 0
	this->power = 100;	// default 100 units
}

Robot::Robot()
{
	this->x = 0;		// default 0
	this->y = 0;		// default 0
	this->power = 100;	// default 100 units
}

// member functions

// Intent: Get robot x location.
// Pre: none.
// Post: return x of robot.
double Robot::getX()
{
	return x;
} 

// Intent: Get robot y location.
// Pre: none.
// Post: return y of robot.
double Robot::getY()
{
	return y;
}

// Intent: Get robot power value.
// Pre: none.
// Post: return power of robot.
double Robot::getPower()
{
	return power;
}

// Intent: make robot move.
// Pre: delta x and delta y.
// Post: none.
void Robot::move(double deltaX, double deltaY)
{
	double distance = sqrt(deltaX*deltaX + deltaY * deltaY); // calculate move distance

	for (int i=0; i < distance; i++)
	{
		if (power > 0)
		{
			x += (deltaX / distance); // move 1 unit delta x
			y += (deltaY / distance); // move 1 unit delta y
			power--;				  // power lose 1 unit
		}
		else
		{
			break; // no any power -> robot stay 
		}
	}
}

// Intent: make robot convert string.
// Pre: content to be convert.
// Post: return converted string by robot.
string Robot::speak(string content)
{
	int position = 0;
	for (; position < content.size(); position++)
	{
		if (power > 0)
		{
			if (content[position] >= 'A' && content[position] <= 'Z')
			{
				content[position] += 32;
				if (power < 2)	// if dosen't enough power
				{
					break;		// stop covert 
				}
				power -= 2;
			}
			else if (content[position] >= 'a' && content[position] <= 'z')
			{
				content[position] -= 32;
				if (power < 1)	// if dosen't enough power
				{
					break;		// stop covert
				}
				power -= 1;
			}
			else
			{
				if (power < 0.5)	// if dosen't enough power
				{
					break;			// stop covert
				}
				power -= 0.5; 
			}
		}
		else
		{
			break; // stop covert
		}
	}
	string convert = content.assign(content, 0, position); // assign coverted string
	return convert;
}

// Intent: let robot charge its power.
// Pre: charge value.
// Post: none.
void Robot::charge(double add)
{
	power += add; // charge power
}

